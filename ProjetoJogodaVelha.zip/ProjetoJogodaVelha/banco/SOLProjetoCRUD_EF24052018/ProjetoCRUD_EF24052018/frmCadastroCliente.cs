﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCRUD_EF24052018
{
    public partial class frmCadastroCliente : Form
    {
        
        public frmCadastroCliente()
        {
           
            InitializeComponent();
            
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void frmCadastroCliente_Load(object sender, EventArgs e)
        {
            
            //Carregar os estados cadastrados ao iniciar o sistema
            lerCliente(); //Chamar o metodo
            
            
        }

        // Criar o metodo
        public void lerCliente()
        {
            INFONEWEntities1 context = new INFONEWEntities1();
            IEnumerable<Cliente> lista = from p in context.Clientes select p;
            
            dgvEstados.DataSource = lista.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            INFONEWEntities1 context = new INFONEWEntities1();
            Cliente novoCliente = new Cliente()
            {

                Cod_Cli = Convert.ToInt32(txtCodigo.Text),
                Nome_cli = txtNome.Text,
                DataNasci_cli = Convert.ToDateTime(txtData.Text),
                Renda_cli = Convert.ToInt32(txtRenda.Text),
                Sexo_cli = txtSexo.Text
            };
            context.Clientes.Add(novoCliente);
            context.SaveChanges();
            lerCliente();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            // alterar os dados
            INFONEWEntities1 context = new INFONEWEntities1();
            int codigo = Convert.ToInt32(txtCodigo.Text);
            Cliente clienteAtual = context.Clientes.First(p => p.Cod_Cli == codigo);
            clienteAtual.Nome_cli = txtNome.Text;
            clienteAtual.DataNasci_cli = Convert.ToDateTime(txtData.Text);
            clienteAtual.Renda_cli = Convert.ToInt32(txtRenda.Text);
            clienteAtual.Sexo_cli = txtSexo.Text;
            context.SaveChanges();
            lerCliente();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            INFONEWEntities1 context = new INFONEWEntities1();
            int codigoCliente = Convert.ToInt32(txtCodigo.Text);
            Cliente cliente = context.Clientes.First(p => p.Cod_Cli == codigoCliente);
            context.Clientes.Remove(cliente);
            context.SaveChanges();
            lerCliente();
        }

        private void dgvEstados_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            //quando o usuario clicar no controle, exibe o conteúdo da célula referente a primeira coluna

            try
            {
                int codigoEstado = Convert.ToInt32(dgvEstados.Rows[e.RowIndex].Cells[0].Value);
                procuraEstado(codigoEstado);
            }
            catch
            {

            }

        }
        // criar metodo
        private void procuraEstado(int codigoCliente)
        {
            INFONEWEntities1 context = new INFONEWEntities1();
            Cliente cliente = context.Clientes.First(p => p.Cod_Cli == codigoCliente);
            txtCodigo.Text = cliente.Cod_Cli.ToString();
            txtRenda.Text = cliente.Renda_cli.ToString();
            txtNome.Text = cliente.Nome_cli.ToString();
            txtData.Text = cliente.DataNasci_cli.ToString();
            txtSexo.Text = cliente.Sexo_cli.ToString();

        }

        private void dgvEstados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtData_TextChanged(object sender, EventArgs e)
        {
           
        }
    } // fim da classe
}//fim do projeto
