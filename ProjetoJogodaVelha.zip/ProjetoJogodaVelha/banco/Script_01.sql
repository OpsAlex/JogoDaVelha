CREATE DATABASE INFONEW
ON PRIMARY
(
  NAME = 'INFONEW_Data',
  FILENAME = 'c:\banco\INFONEW_Dados.mdf',
  SIZE = 10MB,
  MAXSIZE = 100MB,
  FILEGROWTH = 2MB
)
LOG ON
(
  NAME = 'INFONEW_Log',
  FILENAME = 'c:\banco\INFONEW_log.ldf',
  SIZE = 1MB,
  MAXSIZE = 10MB,
  FILEGROWTH = 1MB
)
GO
/* **************************************************************************/
/* Estabelecendo uma Conex�o com o Database INFONEW      */
           		              	
/* **************************************************************************/

USE  INFONEW
GO

/* **************************************************************************/
/* Criando as tabelas do database INFONEW                              */
	
/* **************************************************************************/
CREATE TABLE TipoEnd
(
  Cod_TipoEnd   int identity not null,
  Nome_TipoEnd  varchar(30)     not null,
  Constraint PK_TipoEnd Primary Key(Cod_TipoEnd),
  Constraint UQ_TipoEnd Unique(Nome_TipoEnd)
)
GO
CREATE TABLE Pais
(
  Cod_pais   int		  Not Null,
  Nome_pais  varchar(100) Not Null,
 
  Constraint PK_pais Primary Key(Cod_pais)
)
GO

CREATE TABLE Estado
(
  Cod_Est  int identity     not null,
  sigla_est char(2)          not null,
  Nome_Est   varchar(100) not null,
  Cod_Pais   int		not null,
  Constraint PK_Est Primary Key(Cod_Est),
  Constraint FK_Est1 Foreign Key(Cod_pais) References Pais(Cod_pais)

  )
GO
CREATE TABLE Cidade
(
  Cod_Cid    int          Not Null,
  Cod_est    int          Not Null,
  Nome_Cid   varchar(100) Not Null,
 
  Constraint PK_Cid Primary Key(Cod_Cid),
  Constraint FK_Cid Foreign Key(Cod_Est) References Estado(Cod_Est)

)
GO

CREATE TABLE TipoCli
(
  Cod_TipoCli  int identity not null,
  Nome_TipoCli varchar(100) not null,
 
  Constraint PK_TipoCli Primary key(Cod_TipoCli),
  Constraint UQ_TipoCli Unique(Nome_TipoCli)
)
GO
CREATE TABLE Cliente
(
  Cod_Cli         int Identity       not null,
  Cod_TipoCli int                     not null,
  Nome_Cli      varchar(100)   not null,
  Data_CadCli datetime not null Default Getdate(),
  Renda_Cli     decimal(10,2) not null Default 0,
  Sexo_Cli       char(01)           not null Default 'F',

  Constraint PK_Cli  Primary Key(Cod_Cli),
  Constraint FK_Cli  Foreign Key(Cod_TipoCli)References TipoCli(Cod_TipoCli),
  Constraint CH_Cli1  Check(Renda_Cli >=0),
  Constraint CH_Cli2  Check(Sexo_Cli IN('F','M'))
)
GO
CREATE TABLE Conjuge
(
  Cod_Cli          int                      not null,
  Nome_Conj   char(30)            not null,
  Renda_Conj  decimal(10,2)   not null Default 0,
  Sexo_Conj    char(01)             not null Default 'M',
  Constraint PK_Conj  Primary Key(Cod_Cli),
  Constraint FK_Conj  Foreign Key(Cod_Cli) References Cliente(Cod_Cli),
  Constraint CH_Conj1 Check(Renda_Conj >=0),
  Constraint CH_Conj2 Check(Sexo_Conj IN ('F','M'))
)
GO
CREATE TABLE Endereco
(
  Cod_End          int identity    not null,
  Cod_TipoEnd  int                 not null,
  Cod_Cid          int                  not null,
  Cod_Cli           int                   not null,
  Nome_Rua     varchar(100)  not null,
  Nome_Bairro  varchar(100)  not null,
  Compl_End    varchar(100)        null,

  Constraint PK_End Primary Key(Cod_End),
  Constraint FK_End1 Foreign Key(Cod_TipoEnd) References TipoEnd(Cod_TipoEnd),
  Constraint FK_End2 Foreign Key(Cod_Cid) References Cidade(Cod_Cid),
  Constraint FK_End3 Foreign Key(Cod_Cli) References Cliente(Cod_Cli)
)
GO
CREATE TABLE Credito
(
  Num_Lanc     int identity        not null,
  Cod_Cli         int                     not null,
  Cred_Cli        decimal(10,2) not null,
  Data_CredCli datetime not null,
  Constraint PK_Cred Primary Key(Num_Lanc),
  Constraint FK_Cred Foreign Key(Cod_Cli) References Cliente(Cod_Cli),
  Constraint CH_Cred Check(Cred_Cli > 0)
)
GO
CREATE TABLE Fone
(
  Num_Lanc int identity   not null, 
  Cod_Cli  int                    not null,
  Num_Fone char(10)      not null,
  Num_DDD  char(05)     not null Default '011',
  Constraint PK_Fone Primary Key(Num_Lanc),
  Constraint FK_Fone Foreign Key(Cod_Cli) References Cliente(Cod_Cli)
)
GO
CREATE TABLE EMail
(
  Num_Lanc  int identity    not null, 
  Cod_Cli      int                  not null,
  EMail_Cli    varchar(255) not null,
  Constraint PK_Email Primary Key(Num_Lanc),
  Constraint FK_Emails Foreign Key(Cod_Cli) References Cliente(Cod_Cli)
)
GO
CREATE TABLE StatusPedido
(
  Cod_Sta    smallint identity  not null,
  Sta_Ped    varchar(100)       not null,
  Constraint PK_StatusPed Primary Key(Cod_Sta),
  Constraint UQ_StatusPed Unique(Sta_Ped)
)
GO
CREATE TABLE Funcionario
(
  Cod_Func        int Identity  not null,
  Nome_Func     varchar(100)  not null,
  Data_CadFunc datetime not null Default Getdate(),
  Sexo_Func       char(01)      not null Default 'F',
  Sal_Func     decimal(10,2) not null Default 200,
  End_Func     varchar(100)  not null,

  Constraint PK_Func  Primary Key(Cod_Func),
  Constraint CH_Func1  Check(Data_CadFunc >=Getdate()),
  Constraint CH_Func2  Check(Sexo_Func IN ('F','M')),
  Constraint CH_Func3  Check(Sal_Func >=0)
)
GO
CREATE TABLE Bonus
(
  Num_Lanc   int identity  not null,
  Cod_Func   int           not null,
  Data_Bonus datetime not null default Getdate(),
  Val_Bonus  decimal(10,2) not null, 

  Constraint PK_Bonus Primary Key(Num_Lanc),
  Constraint FK_Bonus Foreign Key(Cod_Func) References Funcionario(Cod_Func),
  Constraint CH_Bonus1 Check(Data_Bonus >= Getdate()),
  Constraint CH_Bonus2 Check(Val_Bonus > 0)
)
GO
CREATE TABLE Pontuacao
(
  Num_Lanc   int identity  not null,
  Cod_Func   int           not null,
  Data_Pto   datetime not null default Getdate(),
  Pto_Func   decimal(4,2)  not null, 

  Constraint PK_Pto Primary Key(Num_Lanc),
  Constraint FK_Pto Foreign Key(Cod_Func) References Funcionario(Cod_Func),
  Constraint CH_Pto1 Check(Data_Pto >= Getdate()),
  Constraint CH_Pto2 Check(Pto_Func > 0)
)
GO 
CREATE TABLE Historico
(
  Num_Lanc  int identity  not null,
  Cod_Func  int           not null, 
  Data_Hist datetime not null Default Getdate(),
  Sal_Ant   decimal(10,2) not null, 
  Sal_Atual decimal(10,2) not null, 

  Constraint PK_Hist  Primary Key(Num_Lanc),
  Constraint FK_Hist  Foreign Key(Cod_Func) References Funcionario(Cod_Func),
  Constraint CH_Hist1 Check(Data_Hist >= Getdate()),
  Constraint CH_Hist2 Check(Sal_Ant >= 0),
  Constraint CH_Hist3 Check(Sal_Ant > 0)
)
GO
CREATE TABLE Dependente
(
  Cod_Dep         int  identity not null,
  Cod_Func        int           not null,
  Nome_Dep       varchar(100)  not null,
  Data_NascDep datetime not null,
  Sexo_Dep        char(01)      not null Default 'F',
 
  Constraint PK_Dep Primary Key(Cod_Dep),
  Constraint FK_Dep Foreign Key(Cod_Func)References Funcionario(Cod_Func),
  Constraint CH_Dep Check(Sexo_Dep IN ('F','M'))
)
GO
CREATE TABLE Pedido
(
  Num_Ped  int identity  not null,
  Cod_Cli  int           not null,
  Cod_Func int           not null,
  Cod_Sta  smallint      not null,
  Data_Ped datetime not null Default Getdate(),
  Val_Ped  decimal(10,2) not null Default 0,

  Constraint PK_Pedido  Primary Key(Num_Ped),
  Constraint FK_Pedido1 Foreign Key(Cod_Cli) References Cliente(Cod_Cli),
  Constraint FK_Pedido2 Foreign Key(Cod_func) References Funcionario(Cod_Func),
  Constraint FK_Pedido3 Foreign Key(Cod_Sta) References StatusPedido(Cod_Sta),
  Constraint CH_Pedido2  Check(Val_Ped >=0)
)
GO
CREATE TABLE Parcela
(
  Num_Par   smallint             not null,
  Num_Ped   int                     not null,
  Data_Venc datetime not null Default getdate(),
  Val_Venc  decimal(10,2)   not null,
  Data_Pgto datetime        null,
  Val_Pgto   as
       CASE
            WHEN Data_Pgto < Data_Venc THEN Val_Venc * 0.9
            WHEN Data_Pgto = Data_Venc THEN Val_Venc 
            WHEN Data_Pgto > Data_Venc THEN Val_Venc * 1.1
      END,

  Constraint PK_Parcela    Primary key(Num_Par,Num_Ped),
  Constraint FK_Parcela    Foreign Key(Num_Ped)References Pedido(Num_Ped),
  Constraint CH_Parcela1 Check(Data_Venc >= getdate()),
  Constraint CH_Parcela2 Check(Val_Venc >= 0),
)  
GO
CREATE TABLE TipoProd
(
  Cod_TipoProd  int identity not null,
  Nome_TipoProd varchar(100) not null,
  
  Constraint PK_TipoProd Primary Key(Cod_TipoProd),
  Constraint UQ_TipoProd Unique(Nome_TipoProd)
)
GO  
CREATE TABLE Produto
(
  Cod_Prod          int identity        not null,
  Cod_TipoProd  int                     not null,
  Nome_Prod       varchar(100)   not null,
  Qtd_EstqProd   int                     not null Default 0,
  Val_UnitProd     decimal(10,2)  not null,
  Val_Total           AS Qtd_EstqProd * Val_UnitProd,
  Constraint PK_Prod  Primary Key(Cod_Prod),
  Constraint FK_Prod  Foreign Key(Cod_TipoProd) References TipoProd(Cod_TipoProd),
  Constraint UQ_Prod  Unique(Nome_Prod),
  Constraint CH_Prod1 Check(Qtd_EstqProd >= 0),
  Constraint CH_Prod2 Check(Val_UnitProd >  0)
)
GO  
CREATE TABLE Itens
(
  Num_Ped    int           not null,
  Cod_Prod   int           not null,
  Qtd_Vend   int           not null,
  Val_Vend   decimal(10,2) not null,

  Constraint PK_Itens   Primary Key(Num_Ped,Cod_Prod),
  Constraint FK_Itens1  Foreign Key(Num_Ped)  References Pedido(Num_Ped),
  Constraint FK_Itens2  Foreign Key(Cod_Prod) References Produto(Cod_Prod),
  Constraint CH_Itens1  Check(Qtd_Vend > 0),
  Constraint CH_Itens2  Check(Val_Vend > 0)
)
GO
/* *********************************************************************************/
/* Verificando a Cria��o da Tabelas do Database INFONEW           */
/*  							      */	
/* *********************************************************************************/
SELECT * FROM Information_Schema.Tables
WHERE Table_Type = 'Base Table'
/* *********************************************************************************/


USE INFONEW

--EXIBIR NOME DO CLIENTE, SEXO, RENDA DO CLIENTE, RENDA COM AUMENTO DE 20%

SELECT NOME_CLI, SEXO_CLI, RENDA_CLI, RENDA_CLI * 1.20 AS [RENDA COM AUMENTO]
FROM Cliente

-- EXIBIR CODIGO DO CLIENTE, NUMERO DO PEDIDO, VALOR PEDIDO, VALOR COM DESCONTO DE 12,5%

SELECT COD_CLI, NUM_PED, VAL_PED, VAL_PED * 0.875 AS [VALOR COM DESCONTO]	
FROM PEDIDO

--EXIBIR NOME,SEXO, RENDA, RENDA COM AUMENTO DE 13,67% PARA TODOS OS CLIENTES DO SEXO FEMININO

SELECT NOME_CLI, SEXO_CLI, RENDA_CLI, RENDA_CLI * 1.1367 AS [VALOR COM AUMENTO]
FROM CLIENTE
WHERE Sexo_Cli ='F'

--EXIBIR TODOS OS DADOS DO CLIENTE DE CODIGO 7

SELECT * FROM CLIENTE
WHERE Cod_Cli=7

--EXIBIR TODOS OS CLIENTES DE CODIGO MAIOR QUE 7 E RENDA MENOR DO QUE 7000

SELECT * FROM Cliente
WHeRE COD_Cli > 7 AND
RENDA_Cli < 7000		

--exibir TODOS OS CLIENTES DIFERENTES DE 5, OU SEXO FEMININO E DATA DE CADASTRO MAIOR DO QUE 01-01-2010


SELECT * FROM Cliente
WHERE Cod_Cli <> 5 OR
Sexo_Cli='F' AND
Data_CadCli > '01-01-2010'

--FAIXA DE VALORES DE TODOS OS CLIENTES QUE TEM RENDA ENTRE 1000 E 3000

SELECT * FROM Cliente
WHERE Renda_Cli BETWEEN 1000 AND 3000


ORDER BY 5

--MOSTRE TODOS OS PEDIDOS DE MAIO DE 2010

SELECT * FROM Pedido
WHERE Data_Ped BETWEEN '01/05/2003' AND '31/05/2003'

SELECT * FROM FUNCIONARIO

SELECT NOME_FUNC, SAL_FUNC, SAL_FUNC * 0,91 AS [VALOR COM DESCONTO]
FROM Funcionario
WHeRE SAL_FUNC > 2500


SELECT * FROM CIDADE
WHERE Cod_Cid BETWEEN '3' AND '8'

SELECT * FROM FUNCIONARIO
WHERE SAL_FUNC BETWEEN '520.23' AND '2544.45'


SELECT * FROM PEDIDO
WHERE Cod_ClI=24 OR 
VAL_PED < 34567.45 AND
 Data_Ped < '12/04/2009'


 SELECT * FROM PEDIDO
WHERE Data_Ped BETWEEN '09/02/2002' AND '02/09/2004'



SELECT * FROM PRODUTO
WHERE Val_UnitProd BETWEEN 435.9 AND 875.23

SELECT * FROM CIDADE
WHERE Cod_Cid BETWEEN 23 AND 567


SELECT * FROM PAIS
WHERE Cod_pais BETWEEN 3 AND 50
