﻿namespace ProjetoJogodaVelha
{
    partial class frmJogodaVelha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.gpbBomJogo = new System.Windows.Forms.GroupBox();
            this.btnReiniciar = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.gpbPlacarGeral = new System.Windows.Forms.GroupBox();
            this.pgbVelha = new System.Windows.Forms.ProgressBar();
            this.pgbJogadorO = new System.Windows.Forms.ProgressBar();
            this.pgbJogadorX = new System.Windows.Forms.ProgressBar();
            this.lblVelha = new System.Windows.Forms.Label();
            this.lblJogadorO = new System.Windows.Forms.Label();
            this.lblPlacarX = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnFinalizar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblNomeX = new System.Windows.Forms.Label();
            this.lblNomeO = new System.Windows.Forms.Label();
            this.btnReiTudo = new System.Windows.Forms.Button();
            this.gpbBomJogo.SuspendLayout();
            this.gpbPlacarGeral.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Seja Bem-Vindo";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(18, 215);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(226, 47);
            this.button1.TabIndex = 3;
            this.button1.Text = "Iniciar Jogo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // gpbBomJogo
            // 
            this.gpbBomJogo.Controls.Add(this.btnReiniciar);
            this.gpbBomJogo.Controls.Add(this.btn9);
            this.gpbBomJogo.Controls.Add(this.btn8);
            this.gpbBomJogo.Controls.Add(this.btn7);
            this.gpbBomJogo.Controls.Add(this.btn6);
            this.gpbBomJogo.Controls.Add(this.btn5);
            this.gpbBomJogo.Controls.Add(this.btn4);
            this.gpbBomJogo.Controls.Add(this.btn3);
            this.gpbBomJogo.Controls.Add(this.btn2);
            this.gpbBomJogo.Controls.Add(this.btn1);
            this.gpbBomJogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbBomJogo.Location = new System.Drawing.Point(261, 20);
            this.gpbBomJogo.Name = "gpbBomJogo";
            this.gpbBomJogo.Size = new System.Drawing.Size(238, 276);
            this.gpbBomJogo.TabIndex = 4;
            this.gpbBomJogo.TabStop = false;
            this.gpbBomJogo.Text = "Bom Jogo";
            this.gpbBomJogo.VisibleChanged += new System.EventHandler(this.gpbBomJogo_VisibleChanged);
            this.gpbBomJogo.Enter += new System.EventHandler(this.gpbBomJogo_Enter);
            // 
            // btnReiniciar
            // 
            this.btnReiniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReiniciar.Location = new System.Drawing.Point(6, 246);
            this.btnReiniciar.Name = "btnReiniciar";
            this.btnReiniciar.Size = new System.Drawing.Size(217, 29);
            this.btnReiniciar.TabIndex = 9;
            this.btnReiniciar.Text = "Reiniciar";
            this.btnReiniciar.UseVisualStyleBackColor = true;
            this.btnReiniciar.Click += new System.EventHandler(this.btnReiniciar_Click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(159, 173);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(60, 60);
            this.btn9.TabIndex = 8;
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(82, 173);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(60, 60);
            this.btn8.TabIndex = 7;
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn7
            // 
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(6, 173);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(60, 60);
            this.btn7.TabIndex = 6;
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(159, 98);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(60, 60);
            this.btn6.TabIndex = 5;
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn5
            // 
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(82, 98);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(60, 60);
            this.btn5.TabIndex = 4;
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn4
            // 
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.Location = new System.Drawing.Point(6, 98);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(60, 60);
            this.btn4.TabIndex = 3;
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(159, 19);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(60, 60);
            this.btn3.TabIndex = 2;
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(82, 19);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(60, 60);
            this.btn2.TabIndex = 1;
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(6, 19);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(60, 60);
            this.btn1.TabIndex = 0;
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // gpbPlacarGeral
            // 
            this.gpbPlacarGeral.Controls.Add(this.pgbVelha);
            this.gpbPlacarGeral.Controls.Add(this.pgbJogadorO);
            this.gpbPlacarGeral.Controls.Add(this.pgbJogadorX);
            this.gpbPlacarGeral.Controls.Add(this.lblVelha);
            this.gpbPlacarGeral.Controls.Add(this.lblJogadorO);
            this.gpbPlacarGeral.Controls.Add(this.lblPlacarX);
            this.gpbPlacarGeral.Controls.Add(this.label4);
            this.gpbPlacarGeral.Controls.Add(this.label3);
            this.gpbPlacarGeral.Controls.Add(this.label2);
            this.gpbPlacarGeral.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbPlacarGeral.Location = new System.Drawing.Point(527, 20);
            this.gpbPlacarGeral.Name = "gpbPlacarGeral";
            this.gpbPlacarGeral.Size = new System.Drawing.Size(221, 275);
            this.gpbPlacarGeral.TabIndex = 5;
            this.gpbPlacarGeral.TabStop = false;
            this.gpbPlacarGeral.Text = "Placar Geral";
            this.gpbPlacarGeral.Enter += new System.EventHandler(this.gpbPlacarGeral_Enter);
            // 
            // pgbVelha
            // 
            this.pgbVelha.Location = new System.Drawing.Point(22, 220);
            this.pgbVelha.Name = "pgbVelha";
            this.pgbVelha.Size = new System.Drawing.Size(131, 23);
            this.pgbVelha.TabIndex = 9;
            // 
            // pgbJogadorO
            // 
            this.pgbJogadorO.Location = new System.Drawing.Point(22, 141);
            this.pgbJogadorO.Name = "pgbJogadorO";
            this.pgbJogadorO.Size = new System.Drawing.Size(131, 23);
            this.pgbJogadorO.TabIndex = 8;
            // 
            // pgbJogadorX
            // 
            this.pgbJogadorX.Location = new System.Drawing.Point(22, 52);
            this.pgbJogadorX.Name = "pgbJogadorX";
            this.pgbJogadorX.Size = new System.Drawing.Size(131, 23);
            this.pgbJogadorX.TabIndex = 7;
            this.pgbJogadorX.Click += new System.EventHandler(this.pgbJogadorX_Click);
            // 
            // lblVelha
            // 
            this.lblVelha.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblVelha.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVelha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblVelha.Location = new System.Drawing.Point(41, 246);
            this.lblVelha.Name = "lblVelha";
            this.lblVelha.Size = new System.Drawing.Size(85, 30);
            this.lblVelha.TabIndex = 6;
            this.lblVelha.Text = "0";
            this.lblVelha.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblJogadorO
            // 
            this.lblJogadorO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblJogadorO.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogadorO.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblJogadorO.Location = new System.Drawing.Point(41, 167);
            this.lblJogadorO.Name = "lblJogadorO";
            this.lblJogadorO.Size = new System.Drawing.Size(85, 30);
            this.lblJogadorO.TabIndex = 5;
            this.lblJogadorO.Text = "0";
            this.lblJogadorO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPlacarX
            // 
            this.lblPlacarX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPlacarX.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlacarX.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPlacarX.Location = new System.Drawing.Point(41, 78);
            this.lblPlacarX.Name = "lblPlacarX";
            this.lblPlacarX.Size = new System.Drawing.Size(85, 30);
            this.lblPlacarX.TabIndex = 4;
            this.lblPlacarX.Text = "0";
            this.lblPlacarX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPlacarX.Click += new System.EventHandler(this.lblPlacarX_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(36, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 30);
            this.label4.TabIndex = 3;
            this.label4.Text = "Velha:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(17, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "Jogador O:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(17, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "Jogador X:";
            // 
            // btnFinalizar
            // 
            this.btnFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizar.ForeColor = System.Drawing.Color.Blue;
            this.btnFinalizar.Location = new System.Drawing.Point(49, 268);
            this.btnFinalizar.Name = "btnFinalizar";
            this.btnFinalizar.Size = new System.Drawing.Size(167, 45);
            this.btnFinalizar.TabIndex = 6;
            this.btnFinalizar.Text = "FINALIZAR";
            this.btnFinalizar.UseVisualStyleBackColor = true;
            this.btnFinalizar.Click += new System.EventHandler(this.btnFinalizar_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(-4, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 29);
            this.label5.TabIndex = 7;
            this.label5.Text = "Jogador X:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(-6, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "Jogador O:";
            // 
            // lblNomeX
            // 
            this.lblNomeX.AutoSize = true;
            this.lblNomeX.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeX.ForeColor = System.Drawing.Color.Black;
            this.lblNomeX.Location = new System.Drawing.Point(136, 87);
            this.lblNomeX.Name = "lblNomeX";
            this.lblNomeX.Size = new System.Drawing.Size(83, 31);
            this.lblNomeX.TabIndex = 9;
            this.lblNomeX.Text = "label7";
            // 
            // lblNomeO
            // 
            this.lblNomeO.AutoSize = true;
            this.lblNomeO.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeO.Location = new System.Drawing.Point(136, 142);
            this.lblNomeO.Name = "lblNomeO";
            this.lblNomeO.Size = new System.Drawing.Size(83, 31);
            this.lblNomeO.TabIndex = 10;
            this.lblNomeO.Text = "label7";
            // 
            // btnReiTudo
            // 
            this.btnReiTudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReiTudo.Location = new System.Drawing.Point(37, 216);
            this.btnReiTudo.Name = "btnReiTudo";
            this.btnReiTudo.Size = new System.Drawing.Size(191, 47);
            this.btnReiTudo.TabIndex = 11;
            this.btnReiTudo.Text = "Reiniciar Tudo";
            this.btnReiTudo.UseVisualStyleBackColor = true;
            this.btnReiTudo.Click += new System.EventHandler(this.btnReiTudo_Click);
            // 
            // frmJogodaVelha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 326);
            this.Controls.Add(this.btnReiTudo);
            this.Controls.Add(this.lblNomeO);
            this.Controls.Add(this.lblNomeX);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnFinalizar);
            this.Controls.Add(this.gpbPlacarGeral);
            this.Controls.Add(this.gpbBomJogo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "frmJogodaVelha";
            this.Text = "Menu Principal do Jogo";
            this.gpbBomJogo.ResumeLayout(false);
            this.gpbPlacarGeral.ResumeLayout(false);
            this.gpbPlacarGeral.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox gpbBomJogo;
        private System.Windows.Forms.Button btnReiniciar;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.GroupBox gpbPlacarGeral;
        private System.Windows.Forms.Label lblVelha;
        private System.Windows.Forms.Label lblJogadorO;
        private System.Windows.Forms.Label lblPlacarX;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar pgbVelha;
        private System.Windows.Forms.ProgressBar pgbJogadorO;
        private System.Windows.Forms.ProgressBar pgbJogadorX;
        private System.Windows.Forms.Button btnFinalizar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblNomeX;
        private System.Windows.Forms.Label lblNomeO;
        private System.Windows.Forms.Button btnReiTudo;
    }
}

